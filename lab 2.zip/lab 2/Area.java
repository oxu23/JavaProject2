//NAME: Oliver Xu
//SMU ID: 48824898
//LAB: Lab 2 Spring 2023


import java.util.Scanner;

public class Area
{
	public static void main (String[] args)
	{
		Scanner input = new Scanner(System.in);

		menu();	
		int i = input.nextInt();

		while (i != 0)
		{
			if (i == 1)
			{
				calculateSquareArea(input);
				menu();
				i = input.nextInt();
			}
			else if (i == 2)
			{
				calculateRectangleArea(input);
				menu();
				i = input.nextInt();
			}
			else if (i == 3)
			{
				calculateTriangleArea(input);
				menu();
				i = input.nextInt();
			}
			else if (i == 4)
			{
				calculateCircleArea(input);
				menu();
				i = input.nextInt();
			}
		}
		
	}

	public static void menu()
	{
		System.out.println("Choose an area to calculate");
		System.out.println("1: square");
		System.out.println("2: rectangle");
		System.out.println("3: triangle");
		System.out.println("4: circle");
		System.out.println("0 to exit");	
	}
	
	public static void calculateSquareArea(Scanner input)
	{
		System.out.println("Enter the side length: ");
		double square_length = input.nextDouble();
		double square_area = square_length * square_length;
		System.out.println("Area of square is: " + square_area);
	}

	public static void calculateRectangleArea(Scanner input)
	{
		System.out.println("Enter the side length: ");
		double rec_length = input.nextDouble();

		System.out.println("Enter the side width: ");
		double rec_width = input.nextDouble();

		double rec_area = rec_length * rec_width;
		System.out.println("Area of rectangle is: " + rec_area);
	}

	public static void calculateTriangleArea(Scanner input)
	{
		System.out.println("Enter the base length: ");
		double tri_base = input.nextDouble();

		System.out.println("Enter the height: ");
		double tri_height = input.nextDouble();

		double tri_area = (tri_base * tri_height) / 2;
		System.out.println("Area of triangle is: " + tri_area);
	}

	public static void calculateCircleArea(Scanner input)
	{
		System.out.println("Enter the radius length: ");
		double rad_length = input.nextDouble();
		double cir_area = rad_length * rad_length * 3.14;
		System.out.println("Area of circle is: " + cir_area);
	}

}

