//NAME: Oliver Xu
//SMU ID: 48824898
//LAB: Lab 2 Spring 2023


import java.util.Scanner;

public class Raise
{
  public static void main(String[]args)
  {

   Scanner scan = new Scanner(System.in);
   
   System.out.println("Enter starting salary: ");
   double s = scan.nextDouble();

   System.out.println("Enter starting raise percentage: ");
   double rp = scan.nextDouble();
   rp = rp/100;

   double total = 0;
   double new_total = 0;
  
   for (int i = 0; i < 10; i++)
   {
	System.out.printf(" Year %2d $ %,9.2f", (i + 1), s);
	total = s;

	rp = rp * 100;
	System.out.printf("%,9.2f%s\n", rp, "%");
	rp = rp / 100;

	s = (1 + rp) * s;
	rp = rp - 0.001;	

	new_total += total;

   }
	
	System.out.printf(" Total   $%,2.2f\n", new_total);	
  }
} 
