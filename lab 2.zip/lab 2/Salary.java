//NAME: Oliver Xu
//SMU ID: 48824898
//LAB: Lab 2 Spring 2023


import java.util.Scanner;

public class Salary
{
  public static void main(String[]args)
  {

   Scanner scan = new Scanner(System.in);
   
   System.out.println("Enter annual salary: ");
   double salary = scan.nextInt();

   System.out.println("Enter hourly contract rate: ");
   int cr = scan.nextInt();

   System.out.println("Enter project duration: ");
   int pd = scan.nextInt();

   System.out.println("Enter work hours per day: ");
   int wh = scan.nextInt();

   System.out.println("Enter work days per month: ");
   int wd = scan.nextInt();

   System.out.println("Enter holidays: ");
   int h = scan.nextInt();

   System.out.println("Enter vacation days: ");
   int vd = scan.nextInt();

   System.out.println("Enter income tax rate: ");
   double itr = scan.nextDouble() / 100;

   double sgi = (salary / 12) * pd;
   System.out.println("SALARIED");
   System.out.printf("%49s %,9.2f\n", "Gross Income $", sgi); 
  


   double cgi = wh * wd * pd * cr;
   System.out.println("CONTRACT");
   System.out.printf("%49s%,-1.2f\n", "Gross income $", cgi);

   System.out.println("");


   double gd = cgi - sgi;
   System.out.printf("%49s %,9.2f\n", "Gross difference $", gd);
 

   double mi = 10000;
   System.out.printf("%49s %,9.2f\n", "- medical insurance $", mi);

   double set = itr * cgi;
   System.out.printf("%49s %,9.2f\n", "- self employment tax $", set);

   double uh = h * wh * cr;
   System.out.printf("%49s %,9.2f\n", "- unpaid holidays $", uh);

   double uv = vd * wh * cr;
   System.out.printf("%49s %,9.2f\n", "- unpaid vacation $", uv);

   double nd = gd - mi - set - uh - uv;
   System.out.println("");
   System.out.printf("%49s %,9.2f\n", "NET DIFFERENCE $", nd);


  }
} 
